/*
*********************************************************************************************************
*                                             uC/TCP-IP
*                                      The Embedded TCP/IP Suite
*
*                         (c) Copyright 2004-2014; Micrium, Inc.; Weston, FL
*
*                  All rights reserved.  Protected by international copyright laws.
*
*                  uC/TCP-IP is provided in source form to registered licensees ONLY.  It is
*                  illegal to distribute this source code to any third party unless you receive
*                  written permission by an authorized Micrium representative.  Knowledge of
*                  the source code may NOT be used to develop a similar product.
*
*                  Please help us continue to provide the Embedded community with the finest
*                  software available.  Your honesty is greatly appreciated.
*
*                  You can find our product's user manual, API reference, release notes and
*                  more information at: https://doc.micrium.com
*
*                  You can contact us at: http://www.micrium.com
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                  NETWORK DEVICE CONFIGURATION FILE
*
*                                            GMAC 10/100
*
* Filename      : net_dev_gmac_cfg.h
* Version       : V3.01.00.00
* Programmer(s) : FF
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               MODULE
*
* Note(s) : (1) This network device configuration header file is protected from multiple pre-processor
*               inclusion through use of the network module present pre-processor macro definition.
*********************************************************************************************************
*/

#ifndef  NET_DEV_GMAC_CFG_MODULE_PRESENT                        /* See Note #1.                                         */
#define  NET_DEV_GMAC_CFG_MODULE_PRESENT


/*
*********************************************************************************************************
*                                    NETWORK DEVICE CONFIGURATION
*
* Note(s) : (1) Configurations are done for board/application setup and it must be updated according to
*               application/projects requirements.
*********************************************************************************************************
*/

                                                                /* Declare each specific devices' configuration (see Note #1) : */

extern  const  NET_DEV_CFG_ETHER  NetDev_Cfg_SK_FM3_176PMC_ETH; /*   Example Ethernet     cfg for SK-FM3-176PMC-ETH board       */
extern  const  NET_PHY_CFG_ETHER  NetPhy_Cfg_SK_FM3_176PMC_ETH; /*   Example Ethernet Phy cfg for SK-FM3-176PMC-ETH board       */

extern  const  NET_DEV_CFG_ETHER  NetDev_Cfg_MCB1800;           /*   Example Ethernet     cfg for MCB1800 board                 */
extern  const  NET_PHY_CFG_ETHER  NetPhy_Cfg_MCB1800;           /*   Example Ethernet Phy cfg for MCB1800 board                 */

extern  const  NET_DEV_CFG_ETHER  NetDev_Cfg_LPC_4350_DB1;      /*   Example Ethernet     cfg for LPC-4350-DB1 board            */
extern  const  NET_PHY_CFG_ETHER  NetPhy_Cfg_LPC_4350_DB1;      /*   Example Ethernet Phy cfg for LPC-4350-DB1 board            */

extern  const  NET_DEV_CFG_ETHER  NetDev_Cfg_uCEVALSTM32F107;   /*   Example Ethernet     cfg for uC-Eval-STM32F107 board       */
extern  const  NET_PHY_CFG_ETHER  NetPhy_Cfg_uCEVALSTM32F107;   /*   Example Ethernet Phy cfg for uC-Eval-STM32F107 board       */

/*
*********************************************************************************************************
*                                             MODULE END
*
* Note(s) : (1) See 'net_dev_cfg.h  MODULE'.
*********************************************************************************************************
*/

#endif                                                          /* End of net dev cfg module include.                   */

