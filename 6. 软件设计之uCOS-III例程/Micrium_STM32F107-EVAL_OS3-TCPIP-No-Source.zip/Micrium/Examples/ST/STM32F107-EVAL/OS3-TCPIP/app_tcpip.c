/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                          (c) Copyright 2003-2009; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                              uC/TCP-IP
*                                           APPLICATION CODE
*
* Filename      : app_tcpip.c
* Version       : V1.00
* Programmer(s) : FT
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include <app_tcpip.h>

/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                    LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      App_TCPIP_Init()
*
* Description : uC/TCP-IP Application initialization.
*
* Argument(s) : none
*
* Return(s)   : none
*
* Caller(s)   : Application
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  App_TCPIP_Init ()
{
    NET_IF_NBR   if_nbr;
    NET_IPv4_ADDR  ip;
    NET_IPv4_ADDR  msk;
    NET_IPv4_ADDR  gateway;
    NET_ERR      err;
    CPU_BOOLEAN  cfg_success;


    APP_TRACE_INFO(("Initializing uC/TCP-IP ... \n\r"));


    err = Net_Init(&NetRxTaskCfg,
                   &NetTxDeallocTaskCfg,
                   &NetTmrTaskCfg);                             /* Initialize uC/TCP-IP.                            */

    if (err != NET_ERR_NONE) {
        APP_TRACE_INFO(("uC/TCPIP: Net_Init() error %d \n", err));
        return;
    }

    if_nbr  = NetIF_Add((void    *)&NetIF_API_Ether,            /* Ethernet  interface API.                         */
                        (void    *)&NetDev_API_GMAC,            /* GMAC device API.                                 */
                        (void    *)&NetDev_BSP_STM32Fxxx,       /* STM32F107 device BSP.                            */
                        (void    *)&NetDev_Cfg_STM32F107_0,     /* STM32F107 device configuration.                  */
                        (void    *)&NetPhy_API_Generic,         /* Generic   Phy API.                               */
                        (void    *)&NetPhy_Cfg_STM32F107_0,     /* STM32F107 PHY configuration.                     */
                        (NET_ERR *)&err);                       /* Return error variable.                           */

    if (err != NET_IF_ERR_NONE) {
        APP_TRACE_INFO(("uC/TCPIP: NetIF_Add() error %d \n", err));
        return;
    }

    ip      = NetASCII_Str_to_IPv4((CPU_CHAR *)APP_TCPIP_CFG_IF_IP_ADDR_STR, &err);
    msk     = NetASCII_Str_to_IPv4((CPU_CHAR *)APP_TCPIP_CFG_IF_MASK_STR,    &err);
    gateway = NetASCII_Str_to_IPv4((CPU_CHAR *)APP_TCPIP_CFG_IF_GATEWAY_STR, &err);

    cfg_success = NetIPv4_CfgAddrAdd(if_nbr, ip, msk, gateway,  &err);
   (void)&cfg_success;

    NetIF_Start(if_nbr, &err);

}
