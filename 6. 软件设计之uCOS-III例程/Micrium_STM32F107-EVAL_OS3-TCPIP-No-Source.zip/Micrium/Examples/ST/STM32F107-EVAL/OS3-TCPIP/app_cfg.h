/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                          (c) Copyright 2003-2013; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                      APPLICATION CONFIGURATION
*
*                                     ST Microelectronics STM32
*                                              on the
*
*                                     Micrium uC-Eval-STM32F107
*                                        Evaluation Board
*
* Filename      : app_cfg.h
* Version       : V1.00
* Programmer(s) : FT
*                 DC
*                 MD
*********************************************************************************************************
*/

#ifndef  APP_CFG_MODULE_PRESENT
#define  APP_CFG_MODULE_PRESENT


/*
*********************************************************************************************************
*                                       MODULE ENABLE / DISABLE
*********************************************************************************************************
*/

#define  APP_CFG_TCPIP_EN                               DEF_ENABLED
#define  APP_CFG_SERIAL_EN                              DEF_ENABLED


/*
*********************************************************************************************************
*                                            TASK PRIORITIES
*********************************************************************************************************
*/

#define  APP_TASK_START_PRIO                            5

#define  NET_OS_CFG_TMR_TASK_PRIO                       6
#define  NET_OS_CFG_IF_TX_DEALLOC_TASK_PRIO             7
#define  NET_OS_CFG_IF_LOOPBACK_TASK_PRIO               8
#define  NET_OS_CFG_IF_RX_TASK_PRIO                     9


/*
*********************************************************************************************************
*                                            TASK STACK SIZES
*                             Size of the task stacks (# of OS_STK entries)
*********************************************************************************************************
*/

#define  APP_TASK_START_STK_SIZE                        512

#define  NET_OS_CFG_TMR_TASK_STK_SIZE                   512
#define  NET_OS_CFG_IF_TX_DEALLOC_TASK_STK_SIZE         512
#define  NET_OS_CFG_IF_LOOPBACK_TASK_STK_SIZE           512
#define  NET_OS_CFG_IF_RX_TASK_STK_SIZE                 512



/*
*********************************************************************************************************
*                                            uC/TCP-IP v2.0
*********************************************************************************************************
*/

#define  NET_OS_CFG_IF_LOOPBACK_Q_SIZE                  5
#define  NET_OS_CFG_IF_RX_Q_SIZE                        10
#define  NET_OS_CFG_IF_TX_DEALLOC_Q_SIZE                10


/*
*********************************************************************************************************
*                               uC/TCP-IP v2.0 APPLICATION CONFIGURATION
*********************************************************************************************************
*/

#define  APP_TCPIP_CFG_IF_IP_ADDR_STR                   "10.10.2.81"
#define  APP_TCPIP_CFG_IF_MASK_STR                      "255.255.255.0"
#define  APP_TCPIP_CFG_IF_GATEWAY_STR                   "10.10.2.1"


/*
*********************************************************************************************************
*                                       BSP CONFIGURATION
*********************************************************************************************************
*/

#define  BSP_CFG_SER_COMM_SEL                           BSP_SER_COMM_UART_02


/*
*********************************************************************************************************
*                                     TRACE / DEBUG CONFIGURATION
*********************************************************************************************************
*/
#if 0
#define  TRACE_LEVEL_OFF                                0
#define  TRACE_LEVEL_INFO                               1
#define  TRACE_LEVEL_DBG                                2
#endif

#define  APP_TRACE_LEVEL                                TRACE_LEVEL_DBG
#define  APP_TRACE                                      BSP_Ser_Printf

#include  <cpu.h>
void  BSP_Ser_Printf   (CPU_CHAR *format, ...);


#define  APP_TRACE_INFO(x)                      ((APP_TRACE_LEVEL >= TRACE_LEVEL_INFO) ? (void)(APP_TRACE x) : (void)0)
#define  APP_TRACE_DBG(x)                       ((APP_TRACE_LEVEL >= TRACE_LEVEL_DBG ) ? (void)(APP_TRACE x) : (void)0)


#endif
